public enum LockState {
	NL, RLC, WLC, RLT, WLT, RLT_WLC;
}